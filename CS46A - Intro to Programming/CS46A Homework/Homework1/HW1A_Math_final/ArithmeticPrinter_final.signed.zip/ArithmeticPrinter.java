/**
 * Do some arithmetic in the println statement.
 * 
 * @author Kathlen O'Brien
 */
public class ArithmeticPrinter
{
   public static void main(String[] args)
   {
       
     System.out.println(10+20+30+40+50);
     System.out.println(10*20*30*40*50);
   }
}