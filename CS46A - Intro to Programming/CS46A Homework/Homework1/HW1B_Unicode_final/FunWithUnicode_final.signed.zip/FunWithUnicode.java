/**
 * printing Unicode
 * 
 * @author Kathleen O'Brien 
 */
public class FunWithUnicode
{
    public static void main(String[] args)
    {
        System.out.println("|*CAT**|");
        System.out.println("|*\u5973\u306E\u5b50*|");
        System.out.println("|*\u2665\u2615\u263A**|");
    }
}