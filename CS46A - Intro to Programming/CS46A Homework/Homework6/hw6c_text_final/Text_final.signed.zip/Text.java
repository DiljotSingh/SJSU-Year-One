/**
 * Models a line of Text.
 * @author Diljot
 */
public class Text
{
    String text = "";
    /**
     * Constructs a Text object
     * @param theText the text of the string
     */
    public Text(String theText)
    {
        this.text = theText;
    }

    /**
     * Determines if the string is a single digit
     * @param ch the String to test
     * @return true if the string contains a single digit else false
     */
    public boolean isDigit(String ch)
    {
        if (ch.length() != 1)
        {
            return false;
        }
        else 
        {
            return Character.isDigit(ch.charAt(0));
        }
    }

    /**
     * Gets the text
     * @return text
     */
    public String getText()
    {
        return text;
    }

    /**
     * Gets the number of a's in a String
     * @return count the counted number of a's
     */
    public int getACount()
    {
        int count = 0;
        for (int i = 0; i < text.length(); i++)
        {
            String ch = text.substring(i, i+1);
            if (ch.equalsIgnoreCase("a"))
            {
                count++;
            }
        }
        return count;
    }

    /**
     * Gets the digits in a string
     * @return digits the digits in the string
     */
    public String getDigitsOnly()
    {
        String digits = "";
        for(int i=0; i < text.length(); i++)
        {
            if (isDigit(text.substring(i,i+1)))
            {
                digits = digits + text.substring(i,i+1);
            }
        }
        return digits;
    }

    /**
     * Returns a string consisting of the first character of every word in the string
     * @return firstLetters the first character of every word
     */
    public String firsts()
    {
        String firstLetter = "";
        String word = "";

        if (text.length() < 2)
        {
            return text;
        }
        else
        {
            int i = 0;
            while (text.indexOf(" ", i) != -1)
            { 
                firstLetter = firstLetter + text.substring(text.indexOf(" ", i));
                i++;

                
            }
        }
        return firstLetter;
    }
}

